#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>



/* Returns true if random float in [0,1] is less than *
 * numerator/denominator.  Uses only integer math.    */
# define rand_under(numerator, denominator) \
  (rand() < ((RAND_MAX / denominator) * numerator))

/* Returns random integer in [min, max]. */
# define rand_range(min, max) ((rand() % (((max) + 1) - (min))) + (min))
# define UNUSED(f) ((void) f)

#define malloc(size) ({          \
  void *_tmp;                    \
  assert((_tmp = malloc(size))); \
  _tmp;                          \
})

#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

enum terrain_generation {
	path,
	door,
	wall,
	empty,
	forest,
	rocky,
	plains,
	desert,
	center,
	mart,
	tall_grass,
	clearing
};

typedef struct corridor_path {
	int x;
	int y;
} corridor_path;

void findPath();
void showterrainMap();
int used();

int main(int argc, char *argv[])
{
	int i;
	int j;
	srand(time(NULL));

	enum terrain_generation terrainMap[80][21];
	corridor_path exit_from_top;
	exit_from_top.x = (rand() % 60) + 10;
	exit_from_top.y = 0;

	corridor_path exit_from_right;
	exit_from_right.x = 80 - 1;
	exit_from_right.y = (rand() % 15) + 3;

	corridor_path exit_from_bottom;
	exit_from_bottom.x = (rand() % 60) + 10;
	exit_from_bottom.y = 21 - 1;

	corridor_path exit_from_left;
	exit_from_left.x = 0;
	exit_from_left.y = (rand() % 15) + 3;
	for (i = 0; i < 80; i++)
	{
		terrainMap[i][0] = wall;
		terrainMap[i][21 - 1] = wall;

		if (i < 21)
		{
			terrainMap[0][i] = wall;
			terrainMap[80 - 1][i] = wall;
		}
	}
	terrainMap[exit_from_right.x][exit_from_right.y] = door;
	terrainMap[exit_from_bottom.x][exit_from_bottom.y] = door;
	terrainMap[exit_from_top.x][exit_from_top.y] = door;
	terrainMap[exit_from_left.x][exit_from_left.y] = door;

	for (j = 1; j < 21 - 1; j++)
	{
		for (i = 1; i < 80 - 1; i++)
		{
			terrainMap[i][j] = empty;
		}
	}

	corridor_path intersection;
	intersection.x = (rand() % 40) + 20;
	intersection.y = (rand() % 10) + 5;

	findPath(terrainMap, exit_from_top, intersection);
	findPath(terrainMap, intersection, exit_from_bottom);
	findPath(terrainMap, intersection, exit_from_left);
	findPath(terrainMap, intersection, exit_from_right);

	terrainMap[intersection.x][intersection.y] = path;
	terrainMap[exit_from_top.x][1] = path;

	enum terrain_generation quadrants[4];

	enum terrain_generation geographical_location[4];
	geographical_location[0] = forest;
	geographical_location[1] = rocky;
	geographical_location[2] = plains;
	geographical_location[3] = desert;

	int temp;
	temp = rand() % 4;
	quadrants[temp] = tall_grass;

	do
	{
		temp = rand() % 4;
	} while (quadrants[temp] == tall_grass);

	quadrants[temp] = tall_grass;

	for (i = 0; i < 4; i++)
	{
		if (quadrants[i] != tall_grass)
			quadrants[i] = clearing;
	}
	for (j = 1; j < 21 - 2; j++)
	{
		for (i = 1; i < 80 - 2; i++)
		{
			if (terrainMap[i][j] == path)
				break;

			if (terrainMap[i][j] == empty)
				terrainMap[i][j] = quadrants[0]; 
		}

		if (terrainMap[1][j] == path)
			break;
	}
	for (j = 1; j < 21 - 2; j++)
	{
		for (i = 80 - 2; i > 0; i--)
		{
			if (terrainMap[i][j] == path)
				break;

			if (terrainMap[i][j] == empty)
				terrainMap[i][j] = quadrants[1];
		}
		
		if (terrainMap[80 - 2][j] == path)
			break;
	}

	for (j = 21 - 2; j > 0; j--)
	{
		for (i = 1; i < 80 - 2; i++)
		{
			if (terrainMap[i][j] == path)
				break;

			if (terrainMap[i][j] == empty)
				terrainMap[i][j] = quadrants[2];
		}

		if (terrainMap[1][j] == path)
			break;
	}

	for (j = 21 - 2; j > 0; j--)
	{
		for (i = 80 - 2; i > 0; i--)
		{
			if (terrainMap[i][j] == path)
				break;

			if (terrainMap[i][j] == empty)
				terrainMap[i][j] = quadrants[3];
		}

		if (terrainMap[80 - 2][j] == path)
			break;
	}
	temp = rand() % 4;

	for (j = 1; j < 21 - 2; j++)
	{
		for (i = 1; i < 80 - 2; i++)
		{
			if (terrainMap[i][j] == empty)
				terrainMap[i][j] = geographical_location[temp];
		}
	}
	temp = (rand() % 40) + 20;

	for (j = 1; j < 21 - 2; j++)
	{
		if (terrainMap[temp][j] == path)
		{
			if (used(terrainMap, temp, j - 1) == 1 ||
			    used(terrainMap, temp, j - 2) == 1 ||
			    used(terrainMap, temp + 1, j - 1) == 1 ||
			    used(terrainMap, temp + 1, j - 2) == 1)
			{
				temp = (rand() % 76) + 2;
				j = 0;
				continue;
			}

			terrainMap[temp][j - 1] = mart;
			terrainMap[temp][j - 2] = mart;
			terrainMap[temp + 1][j - 1] = mart;
			terrainMap[temp + 1][j - 2] = mart;
			break;
		}
	}

	temp = (rand() % 10) + 5;

	for (i = 1; i < 80 - 2; i++)
	{
		if (terrainMap[i][temp] == path)
		{
			if (used(terrainMap, i - 1, temp) == 1 ||
			    used(terrainMap, i - 2, temp) == 1 ||
			    used(terrainMap, i - 1, temp + 1) == 1 ||
			    used(terrainMap, i - 2, temp + 1) == 1)
			{
				temp = (rand() % 17) + 2;
				i = 0;
				continue;
			}

			terrainMap[i - 1][temp] = center;
			terrainMap[i - 2][temp] = center;
			terrainMap[i - 1][temp + 1] = center;
			terrainMap[i - 2][temp + 1] = center;
			break;
		}
	}
	showterrainMap(terrainMap);
	return 0;
}

void showterrainMap(enum terrain_generation terrainMap[80][21])
{
	int i;
	int j;
	printf("\033[0;37m");

	for (j = 0; j < 21; j++)
	{
		for (i = 0; i < 80; i++)
		{
			if (terrainMap[i][j] == wall)
				printf("%%");
			else if (terrainMap[i][j] == tall_grass)
			{
				printf("\033[0;32m");
				printf("%s", ",");
			}		

			else if (terrainMap[i][j] == clearing)
				printf("%s", ".");
				
			else if (terrainMap[i][j] == door)
			{
				printf("\033[0;34m");
				printf("%s", "O");
			}
			
			else if (terrainMap[i][j] == path)
			{
				printf("\033[0;34m");
				printf("%s", "#");
			}

			else if (terrainMap[i][j] == forest)
			{
				printf("\033[0;32m");
				printf("%s", "^");
			}

			else if (terrainMap[i][j] == rocky)
				printf("%%");
			else if (terrainMap[i][j] == plains)
			{
				printf("\033[1;33m");
				printf("%s", "/");
			}

			else if (terrainMap[i][j] == desert)
			{
				printf("\033[1;33m");
				printf("%s", "~");
			}

			else if (terrainMap[i][j] == center)
			{
				printf("\033[0;31m");
				printf("%s", "C");
			}

			else if (terrainMap[i][j] == mart)
			{
				printf("\033[0;31m");
				printf("%s", "M");
			}

			else
				printf("%s", " ");

			printf("\033[0;37m");
		}
		
		printf("\n");
	}
}

void showterrainMap(enum terrain_generation terrainMap[80][21]);

int used(enum terrain_generation terrainMap[80][21], int x, int y)
{
	enum terrain_generation t = terrainMap[x][y];

	if (t == path || t == wall || t == mart || t == center || t == door)
		return 1;

	return 0;
}
void findPath(enum terrain_generation terrainMap[80][21], corridor_path a, corridor_path b)
{
	int visit[80][21];
	int distance[80][21];

	int i;
	int j;
	
	
	for (j = 0; j < 21; j++)
	{
		for (i = 0; i < 80; i++)
		{
			visit[i][j] = 0;
			distance[i][j] = 9999;
		}
	}

	
	distance[a.x][a.y] = 0;

	
	corridor_path showparent[80][21];

	
	showparent[a.x][a.y].x = -1;

	corridor_path coordinate;
	int mindlist;

	
	while (visit[b.x][b.y] == 0)
	{

		mindlist = 9999;

		
		for (j = 0; j < 21; j++)
		{
			for (i = 0; i < 80; i++)
			{
				
				if (visit[i][j] == 1)
					continue;

				if (distance[i][j] < mindlist)
				{
					coordinate.x = i;
					coordinate.y = j;
					mindlist = distance[i][j];
				}				
			}
		}

		
		visit[coordinate.x][coordinate.y] = 1;

		
		for (j = coordinate.y - 1; j <= coordinate.y + 1; j++)
		{
			for (i = coordinate.x - 1; i <= coordinate.x + 1; i++)
			{
				
				if (i != coordinate.x && j != coordinate.y)
					continue;

				if (terrainMap[i][j] == wall)
					continue;
					
				if (visit[i][j] == 1)
					continue;
				
				if (mindlist + 1 < distance[i][j])
				{
					distance[i][j] = mindlist + 1;
			       		showparent[i][j] = coordinate;
				}
			}
		}
	}

	i = showparent[b.x][b.y].x;
	j = showparent[b.x][b.y].y;

	while (showparent[i][j].x != -1)
	{
		terrainMap[i][j] = path;
		i = showparent[i][j].x;
		j = showparent[i][j].y;
	}
}

