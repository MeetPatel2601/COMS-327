#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int enter[8];
int go_away[8];
int giveResult[4];

char globe[21][80][399][399];
int North_East[4];
int East_West[4];

void generate_EastToWestPath();
void generate_NorthSouthPath();
int empty_Method();
void generate_TallGrass();
void generate_CenterAndMart();
void generate_RandomObject();
void generateSeed();
void printTerrain();
void Map_Check();
int main(void) {
    int x = 199;
    int y = 199;
    int calculate_Distance;
	char input;

    srand(time(0));
    generateSeed(x, y, giveResult, calculate_Distance);
    printTerrain(x, y);
    while (input != 'q') {
        scanf(" %c", &input);
        switch(input) {
            case 's':
                y--;
                if (y < 0) {
                    printf("Error\n");
                    y++;
                }
                if (globe[0][0][x][y] != '%') {
                    Map_Check(x, y);
                    calculate_Distance = abs(199 - x) + abs(199 - y);
                    generateSeed(x, y, giveResult, calculate_Distance);
                }
                printTerrain(x, y);
                break;
            case 'e':
                x++;
                if (x > 398) {
                    printf("Error\n");
                    x--;
                }
                if (globe[0][0][x][y] != '%') {
                    Map_Check(x, y);
                    calculate_Distance = abs(199 - x) + abs(199 - y);
                    generateSeed(x, y, giveResult, calculate_Distance);
                }
                printTerrain(x, y);
                break;
				case 'n':
                y++;
                if (y > 398) {
                    printf("Error\n");
                    y--;
                }
                if (globe[0][0][x][y] != '%') {
                    Map_Check(x, y);
                    calculate_Distance = abs(199 - x) + abs(199 - y);
                    generateSeed(x, y, giveResult, calculate_Distance);
                }
                printTerrain(x, y);
                break;
            case 'w':
                x--;
                if (x < 0) {
                    printf("Error\n");
                    x++;
                }
                if (globe[0][0][x][y] != '%') {
                    Map_Check(x, y);
                    calculate_Distance = abs(199 - x) + abs(199 - y);
                    generateSeed(x, y, giveResult, calculate_Distance);
                }
                printTerrain(x, y);
                break;
            case 'f':
                scanf("%d %d", &x, &y);
                if (x > 398 || y > 398 || x < 0 || y < 0) {
                    printf("Error, returned to start\n");
                    x = 199;
                    y = 199;
                }
                if (globe[0][0][x][y] != '%') {
                    Map_Check(x, y);
                    calculate_Distance = abs(199 - x) + abs(199 - y);
                    generateSeed(x, y, giveResult, calculate_Distance);
                }
                printTerrain(x, y);
                break;
            default:
                printf(" Pls try again!\n");
                printTerrain(x, y);
                break;
        }
    }
    return 0;
}

void generate_NorthSouthPath(int globeX, int globeY, int path_location[4]) {
    int start = (rand() % 70) + 4;

    if (path_location[3] == 1) {
        start = enter[7];
        globe[20][start][globeX][globeY] = '#';

        int loc[] = {19, start};
        globe[loc[0]][loc[1]][globeX][globeY] = '#';

        while (loc[0] > 0) {
            int num = rand() % 10;

            if (num < 6) {
                loc[0] = loc[0] - 1;
            } else if (num >= 6 && num <= 7) {
                loc[1] = loc[1] - 1;
                if (loc[1] < 3) {
                    loc[1] = loc[1] + 1;
                }
            } else {
                loc[1] = loc[1] + 1;
                if (loc[1] > 73) {
                    loc[1] = loc[1] - 1;
                }
            }
            globe[loc[0]][loc[1]][globeX][globeY] = '#';
        }
        North_East[2] = loc[0];
        North_East[3] = loc[1];
    } else if (path_location[2] == 1) {
        start = go_away[5];
        globe[0][start][globeX][globeY] = '#';

        int loc[] = {1, start};
        globe[loc[0]][loc[1]][globeX][globeY] = '#';

        while (loc[0] < 20) {
            int num = rand() % 10;

            if (num < 6) {
                loc[0] = loc[0] + 1;
            } else if (num >= 6 && num <= 7) {
                loc[1] = loc[1] - 1;
                if (loc[1] < 3) {
                loc[1] = loc[1] + 1;
                }
            } else {
                loc[1] = loc[1] + 1;
                if (loc[1] > 73) {
                loc[1] = loc[1] - 1;
                }
            }
            globe[loc[0]][loc[1]][globeX][globeY] = '#';
        }
        North_East[2] = loc[0];
        North_East[3] = loc[1];
    } else {
        North_East[0] = start;
        North_East[1] = 0;
        globe[0][start][globeX][globeY] = '#';

        int loc[] = {1, start};
        globe[loc[0]][loc[1]][globeX][globeY] = '#';

        while (loc[0] < 20) {
            int num = rand() % 10;

            if (num < 6) {
                loc[0] = loc[0] + 1;
            } else if (num >= 6 && num <= 7) {
                loc[1] = loc[1] - 1;
                if (loc[1] < 3) {
                    loc[1] = loc[1] + 1;
                }
            } else {
                loc[1] = loc[1] + 1;
                if (loc[1] > 73) {
                    loc[1] = loc[1] - 1;
                }
            }
            globe[loc[0]][loc[1]][globeX][globeY] = '#';
        }
        North_East[2] = loc[0];
        North_East[3] = loc[1];
    }
    if (globeY == 398) {
        globe[0][start][globeX][globeY] = '%';
    }
    if (globeY == 0) {
        globe[20][North_East[3]][globeX][globeY] = '%';
    }
}
void generate_EastToWestPath(int globeX, int globeY, int path_location[4]) {
    int start = (rand() % 12) + 4;

    if (path_location[0] == 1) {
        start = enter[0];
        globe[start][79][globeX][globeY] = '#';

        int loc[] = {start, 78};
        globe[loc[0]][loc[1]][globeX][globeY] = '#';

        while (loc[1] > 0) {
            int num = rand() % 10;

            if (num < 6) {
                loc[1] = loc[1] - 1;
            } else if (num >= 6 && num <= 7) {
                loc[0] = loc[0] - 1;
                if (loc[0] < 3) {
                    loc[0] = loc[0] + 1;
                }
            } else {
                loc[0] = loc[0] + 1;
                if (loc[0] > 17) {
                    loc[0] = loc[0] - 1;
                }
            }
            globe[loc[0]][loc[1]][globeX][globeY] = '#';
        }
        East_West[2] = loc[1];
        East_West[3] = loc[0];
    } else if (path_location[1] == 1) {
        start = go_away[2];
        globe[start][0][globeX][globeY] = '#';

        int loc[] = {start, 1};
        globe[loc[0]][loc[1]][globeX][globeY] = '#';

        while (loc[1] < 79) {
            int num = rand() % 10;

            if (num < 6) {
                loc[1] = loc[1] + 1;
            } else if (num >= 6 && num <= 7) {
                loc[0] = loc[0] - 1;
                if (loc[0] < 3) {
                    loc[0] = loc[0] + 1;
                }
            } else {
                loc[0] = loc[0] + 1;
                if (loc[0] > 17) {
                    loc[0] = loc[0] - 1;
                }
            }
            globe[loc[0]][loc[1]][globeX][globeY] = '#';
        }
        East_West[2] = loc[1];
        East_West[3] = loc[0];
    } else {
        East_West[0] = start;
        East_West[1] = 0;
        globe[start][0][globeX][globeY] = '#';

        int loc[] = {start, 1};
        globe[loc[0]][loc[1]][globeX][globeY] = '#';

        while (loc[1] < 79) {
            int num = rand() % 10;

            if (num < 6) {
                loc[1] = loc[1] + 1;
            } else if (num >= 6 && num <= 7) {
                loc[0] = loc[0] - 1;
                if (loc[0] < 3) {
                    loc[0] = loc[0] + 1;
                }
            } else {
                loc[0] = loc[0] + 1;
                if (loc[0] > 17) {
                    loc[0] = loc[0] - 1;
                }
            }
            globe[loc[0]][loc[1]][globeX][globeY] = '#';
        }
        East_West[2] = loc[1];
        East_West[3] = loc[0];
    }
    if (globeX == 398) {
        globe[East_West[3]][79][globeX][globeY] = '%';
    }
    if (globeX == 0) {
        globe[start][0][globeX][globeY] = '%';
    }
}

int empty_Method(int right1, int center1, int right2, int center2, int right3, int center3, int right4, int center4, int varities, int globeX, int globeY) {
    int count = 0;
    if (varities == 1) {
        int surronding[] = {
        globe[right1-1][center1][globeX][globeY], globe[right1][center1-1][globeX][globeY],
        globe[right2+1][center1][globeX][globeY], globe[right2][center1-1][globeX][globeY],
        globe[right1-1][center2][globeX][globeY], globe[right1][center2+1][globeX][globeY],
        globe[right2+1][center2][globeX][globeY], globe[right2][center2+1][globeX][globeY]
        };

        for (int k = 0; k < 12; k++) {
            if (surronding[k] == '#') {
                count++;     
            }
        }
    }


    for (int i = 1; i < 21; i++) {
        for (int j = 1; j < 80; j++) {
            if (globe[right1][center1][globeX][globeY] != '.' || globe[right2][center2][globeX][globeY] != '.' || globe[right3][center3][globeX][globeY] != '.' || globe[right4][center4][globeX][globeY] != '.') {
                return 0;
            }
        }
    }

    if (varities == 1 && count > 0) {
        return 1;
    } else {
        return 0;
    }

}

void generate_TallGrass(int globeX, int globeY) {
    int row = (rand() % 10) + 5;
    int col = (rand() % 70) + 5;
    int origCol = col;
    int rows[8];
    int count = 0;

    while (count <= 5 && globe[row][col][globeX][globeY] == '.' && row > 4 && row < 16) {
        rows[count] = row;
        globe[row][col][globeX][globeY] = ':';
        row = row + 1;
        int count2 = 0;
        col = origCol;
        while (count2 < 8 && globe[row][col][globeX][globeY] == '.' && col > 4 && row < 76) {
            if (globe[row][col][globeX][globeY] == '.' && col > 4 && col < 76) {
                globe[row][col][globeX][globeY] = ':';
            }
            col = col + 1;
            count2++;
        }
        count++;
    }

    if (count < 3) {
        for (int i = 0; i < 8; i++) {
            if (rows[i] != 0 && rows[i] > 4 && rows[i] < 16) {
                globe[rows[i]][col][globeX][globeY] = '.'; 
            } else {
                break;
            }
        }
        generate_TallGrass(globeX, globeY);
      }
}

void generate_CenterAndMart(int globeX, int globeY, int calculate_Distance) {
    int centerright1 = 0;
    int centercenter1 = 0;
    int centerright2 = 0;
    int centercenter2 = 0;
    int check = 0;

    if (calculate_Distance == 0.0) {
        while (check == 0) {
            centerright1 = (rand() % 10) + 5;
            centercenter1 = (rand() % 70) + 5;
            centerright2 = centerright1 + 1;
            centercenter2 = centercenter1 + 1;
            check = empty_Method(centerright1, centercenter1, centerright2, centercenter1, centerright1, centercenter2, centerright2, centercenter2, 1, globeX, globeY);
        }

        globe[centerright1][centercenter1][globeX][globeY] = 'C';
        globe[centerright2][centercenter1][globeX][globeY] = 'C';
        globe[centerright1][centercenter2][globeX][globeY] = 'C';
        globe[centerright2][centercenter2][globeX][globeY] = 'C';

        int martright1 = 0;
        int martcenter1 = 0;
        int martright2 = 0;
        int martcenter2 = 0;
        check = 0;

        while (check == 0) {
            martright1 = (rand() % 10) + 5;
            martcenter1 = (rand() % 70) + 5;
            martright2 = martright1 + 1;
            martcenter2 = martcenter1 + 1;
            check = empty_Method(martright1, martcenter1, martright2, martcenter1, martright1, martcenter2, martright2, martcenter2, 1, globeX, globeY);
        }

        globe[martright1][martcenter1][globeX][globeY] = 'M';
        globe[martright2][martcenter1][globeX][globeY] = 'M';
        globe[martright1][martcenter2][globeX][globeY] = 'M';
        globe[martright2][martcenter2][globeX][globeY] = 'M';
    } else {
        int num = (rand() % calculate_Distance);
        int num2 = (rand() % calculate_Distance/2);

        if (num <= 14 || num == calculate_Distance || num == calculate_Distance/2) {
            generate_CenterAndMart(globeX, globeY, 0);
        } else if (calculate_Distance >= 20 && num < (calculate_Distance-(num2+(num2/2)+(num2/3)))) {
            generate_CenterAndMart(globeX, globeY, 0);
        } 
    }
}

void generate_RandomObject(int globeX, int globeY) { 
    for (int i = 1; i < 20; i++) {
        for (int j = 1; j < 79; j++) {
            if (globe[i][j][globeX][globeY] == '.') {
                int num = rand() % 50;
                if (num == 3) {
                    globe[i][j][globeX][globeY] = '"';
                } else if (num == 8) {
                    globe[i][j][globeX][globeY] = '%';
                }
            }
        }
    }
}

void Map_Check(int x, int y) {
    giveResult[0] = 0;
    giveResult[1] = 0;
    giveResult[2] = 0;
    giveResult[3] = 0;

    if (globe[0][0][x+1][y] == '%') {
        for (int i = 0; i < 21; i++) {
            if (globe[i][0][x+1][y] == '#') {
                enter[0] = i;
            }
            if (globe[i][79][x+1][y] == '#') {
                go_away[0] = i;
            }
        }

        for (int i = 0; i < 80; i++) {
            if (globe[0][i][x+1][y] == '#') {
                enter[1] = i;
            }
            if (globe[20][i][x+1][y] == '#') {
                go_away[1] = i;
            }
        }
        giveResult[0] = 1;
    }

    if (globe[0][0][x-1][y] == '%') {
        for (int i = 0; i < 21; i++) {
            if (globe[i][0][x-1][y] == '#') {
                enter[2] = i;
            }
            if (globe[i][79][x-1][y] == '#') {
                go_away[2] = i;
            }
        }

        for (int i = 0; i < 80; i++) {
            if (globe[0][i][x-1][y] == '#') {
                enter[3] = i;
            }
            if (globe[20][i][x-1][y] == '#') {
                go_away[3] = i;
            }
        }
        giveResult[1] = 1;
    }

    if (globe[0][0][x][y+1] == '%') {
        for (int i = 0; i < 21; i++) {
            if (globe[i][0][x][y+1] == '#') {
                enter[4] = i;
            }
            if (globe[i][79][x][y+1] == '#') {
                go_away[4] = i;
            }
        }

        for (int i = 0; i < 80; i++) {
            if (globe[0][i][x][y+1] == '#') {
                enter[5] = i;
            }
            if (globe[20][i][x][y+1] == '#') {
                go_away[5] = i;
            }
        }
        giveResult[2] = 1;
    }

    if (globe[0][0][x][y-1] == '%') {
        for (int i = 0; i < 21; i++) {
            if (globe[i][0][x][y-1] == '#') {
                enter[6] = i;
            }
            if (globe[i][79][x][y-1] == '#') {
                go_away[6] = i;
            }
        }

        for (int i = 0; i < 80; i++) {
            if (globe[0][i][x][y-1] == '#') {
                enter[7] = i;
            }
            if (globe[20][i][x][y-1] == '#') {
                go_away[7] = i;
            }
        }
        giveResult[3] = 1;
    }
}

void generateSeed(int globeX, int globeY, int path_location[4], int calculate_Distance) {
    int i, j;
    for (i = 0; i < 21; i++) {
        for (j = 0; j < 80; j++) {
            globe[i][j][globeX][globeY] = '.';
        }
    }

    for (i = 0; i < 21; i++) {
        globe[i][0][globeX][globeY] = '%';
        for (j = 0; j < 80; j++) {
            globe[20][j][globeX][globeY] = '%';
            globe[0][j][globeX][globeY] = '%';
        }
        globe[i][79][globeX][globeY] = '%';
    }
    
    generate_TallGrass(globeX, globeY);
    generate_TallGrass(globeX, globeY);
    generate_TallGrass(globeX, globeY);
    generate_TallGrass(globeX, globeY);
    generate_NorthSouthPath(globeX, globeY, path_location);
    generate_EastToWestPath(globeX, globeY, path_location);
    generate_CenterAndMart(globeX, globeY, calculate_Distance);
    generate_RandomObject(globeX, globeY);

    for (i = 0; i < 21; i++) {
        if (globe[i][0][globeX][globeY] != '%' && globe[i][0][globeX][globeY] != '#') {
            globe[i][0][globeX][globeY] = '%';
        }
        if (globe[i][79][globeX][globeY] != '%' && globe[i][79][globeX][globeY] != '#') {
            globe[i][79][globeX][globeY] = '%';
        }
    }

    for (i = 0; i < 80; i++) {
        if (globe[0][i][globeX][globeY] != '%' && globe[0][i][globeX][globeY] != '#') {
            globe[0][i][globeX][globeY] = '%';
        }
        if (globe[20][i][globeX][globeY] != '%' && globe[20][i][globeX][globeY] != '#') {
            globe[20][i][globeX][globeY] = '%';
        }
    }
}

void printTerrain(int globeX, int globeY) {
    for (int i = 0; i < 21; i++) {
        for (int j = 0; j < 80; j++) {
            if (globe[i][j][globeX][globeY] == '"') {
                printf("\033[0;33m%c", globe[i][j][globeX][globeY]);
            } else if (globe[i][j][globeX][globeY] == '#') {
                printf("\033[0;31m%c", globe[i][j][globeX][globeY]);
            } else if (globe[i][j][globeX][globeY] == ':' || globe[i][j][globeX][globeY] == '.') {
                printf("\033[0;32m%c", globe[i][j][globeX][globeY]);
            } else if (globe[i][j][globeX][globeY] == 'C' || globe[i][j][globeX][globeY] == 'M') {
                printf("\033[0;35m%c", globe[i][j][globeX][globeY]);
            } else {
                printf("\033[0;37m%c", globe[i][j][globeX][globeY]);
            }
        }
        printf("\033[0;37m\n");
    }
}

