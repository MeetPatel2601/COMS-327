void io_initialzie(void);
