#include<string>
#include<iostream>
#include<ncurses.h>
#include<string.h>
#include<ctype.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include "player.h"
#include "game.h"
#include "sudoku.h"
#include "ball.h"
#include "io.h"

using namespace std;



int main(int argc, char* argv[])
{
	
	
  if(argc !=2)
  {
  	cout<<"Please enter number of player (1 or 2) in command line"<<endl;
	return 1;
  }
  if(strcmp(argv[1],"1")!=0 && strcmp(argv[1],"2")!=0 && strcmp(argv[1],"3")!=0 && strcmp(argv[1],"4")!=0)
  {
   	cout<<"Invalid number of player ( enter 1 or 2 or 3 or 4)"<<endl;
	return 1;
  }
  
  cout<<"1.Tictactoe One Player 2. Tictactoe Two player 3. Sudoku 4. PingPong"<<endl;
  char s;
  std::string n;
  
  cout<<"Enter first player  name: "<<endl;
  cin>>n;
  cout<<"Enter first player symbol(X goes first or O goes second) if you choose option 1 and option 2: "<<endl;
  do{
    	cin>>s;
 	if(toupper(s)!='O' && toupper(s)!='X')
    	{
    		cout<<"Only 'O' or 'X' allow. Enter again:"<<endl;
    	}
  }while(toupper(s)!='O' && toupper(s)!='X');
  Player p1(n,toupper(s),true);
  bool p;
  if(strcmp(argv[1],"2")==0)
  {
	cout<<"Enter second player name: "<<endl;
 	cin>>n;
	p=true;
  }
    if(strcmp(argv[1],"3")==0)
  {
	sudoku s;
    
    time_t seed;
    struct timeval tv;
    memset(&s, 0, sizeof (s));
    gettimeofday(&tv, NULL);
    seed = (tv.tv_usec ^ (tv.tv_sec << 20)) & 0xffffffff;

    srand(seed);
    init_game(&s);

    clear();
    refresh();
    print_board();
    print_hints(&s);
    print_specific_num(&s);
    mvaddstr(13, 42, "Use the numpad or vim keys used in ");
    mvaddstr(14, 42, "RLG327 game to move around the board.");
    mvaddstr(16, 42, "Press 'e' to enter in a number 1-9.");
    mvaddstr(18, 42, "Press 'w' for more options.");
    mvaddstr(20, 42, "Press 'q' to quit.");

    s.highlight = 0;
    s.quit = 0;
    s.win = 0;
    s.cursor.x = 0;
    s.cursor.y = 0;
    while(s.quit == 0){
        game_input(&s);
        if(check_win(&s)){
            s.win = 1;
            attron(COLOR_PAIR(COLOR_CYAN));
            attron(A_BOLD);
            mvaddstr(6, 51, "You Win!");
            mvaddstr(8, 42, "Press any key to continue.");
            getch();
            attron(COLOR_PAIR(COLOR_CYAN));
            attron(A_BOLD);
            break;
        }
        else if(s.quit == 1 || s.win == 1){
            break;
        }
    }
    
    endwin();
  }
  if(strcmp(argv[1],"4")==0){
	  const char *line = "________________________________________________________________________________";
	  
	  io_initialzie();
	
	mvprintw(1, 0, line);
	mvprintw(22, 0, line);
	
	refresh();
  PongBall *ball = new PongBall(); 
  unsigned int scoreLeft = 0;
  unsigned int scoreRight = 0;
	
	char mode;
	
	mvprintw(11, 30, "0 for 0-player mode");
	mvprintw(12, 30, "1 for 1-player mode");
	mvprintw(13, 30, "2 for 2-player mode");
	
	while (mode != 'Q' && mode != '1' && mode != '2' && mode != '0'){
		mode = getch();
	}
	
	move(13,0);
	clrtoeol();
	move(12,0);
	clrtoeol();
	move(11,0);
	clrtoeol();
  	
	Paddle *left;
	Paddle *right;
	if (mode == '0') {
		right = new Paddle(79,6,1,'u','j');
		left = new Paddle(0,6,1,'w','s');
	}else if (mode == '1') {
		right = new Paddle(79,6,1,'u','j');
		left = new Paddle(0,6,6,'w','s');
	}else {
		right = new Paddle(79,6,6,'u','j');
		left = new Paddle(0,6,6,'w','s');
	}
	mvprintw(0, 2, "%d", scoreLeft);
	mvprintw(0, 77, "%d", scoreRight);
	refresh();
	
	char in = mode;
	
	while (in != 'Q' && scoreLeft < 7 && scoreRight < 7){
		nodelay(stdscr,1);
		in = getch();
		mvprintw(1, 0, line);
		mvprintw(22, 0, line);
		if (mode == '0') {
			right->moveSmartRight(ball->x, ball->y, ball->directionX, ball->directionY);
			left->moveSmartLeft(ball->x, ball->y, ball->directionX, ball->directionY);
		}else if (mode == '1') {
			left->moveUp(in);
			left->moveDown(in);
			right->moveSmartRight(ball->x, ball->y, ball->directionX, ball->directionY);
		}
		else {
			left->moveUp(in);
			left->moveDown(in);
			right->moveUp(in);
			right->moveDown(in);
		}

		left->draw();
		right->draw();
		mvprintw(ball->ball_get_y(), ball->ball_get_x(), " ");

	   	ball->ball_move();

	   	ball->ball_bounce(left, right);
	   	if(ball->x < 0){
	   		scoreRight++;
				mvprintw(0, 2, "%d", scoreLeft);
				mvprintw(0, 77, "%d", scoreRight);
				if(scoreRight < 7) {
					ball->ball_reset();
				}
	   	}
	   	if(ball->x > 79){
	   		scoreLeft++;
				mvprintw(0, 2, "%d", scoreLeft);
				mvprintw(0, 77, "%d", scoreRight);
	   		if(scoreLeft < 7) {
					ball->ball_reset();
				}
	   	}

	   	ball->ball_draw();
	  	nodelay(stdscr,1);
	
	 	refresh();
		usleep(64000);
	}    
	
  mvprintw(12, 35, "GAME OVER!");


  refresh(); 
    
  getchar();
	endwin();
  return 0;
  }

  else
  {
 	n = "CPU";
	p=false;	
  }
  
  if(p1.getSymbol() == 'X')
	s='O';
  else
	s='X';
  Player p2(n,toupper(s),p);
  Game g(&p1,&p2);
  g.drawBoard();
  endwin();
  return 0;
}


