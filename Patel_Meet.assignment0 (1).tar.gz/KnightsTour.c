#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
// defining chessboards

#define N 5


int row[] = {2,1,-1,-2,-2,-1,1,2,2};
int col[] = {1,2,2,1,-1,-2,-2,-1,1};

// Check if (x,y) are valid coordinates

bool isValid(int x, int y) {
if (x < 0 || y < 0  || x >= N || y >= N) {
return false;
}
return true;

}

// Do the function  recursively

void knightTour (int visited[N][N], int x, int y, int pos) {
visited[x][y] = pos;
if (pos >= N*N) {
for (int i = 0; i < N; i++) {
for (int j = 0; j < N; j++) {
	if (j == N - 1) {

printf("%2d ", visited[i][j]);
	} else 
	{
	printf("%2d, ", visited[i][j]);
	}
}
	

}
printf("\n");


printf("\n");


visited[x][y] = 0;
return;
}


for (int k = 0; k < 8; k++)
{
int newX = x + row[k];
int newY = y + col[k];
if (isValid(newX, newY) && !visited[newX][newY]) {
knightTour(visited, newX, newY, pos + 1);
}
}
visited[x][y] = 0;
}
int main()
{
int visited[N][N];
memset(visited,0,sizeof visited);
int pos = 1;
int i,j;
for(i = 0; i < N; i++) {
	for (j = 0; j < N; j++) {
		
knightTour(visited, i, j, pos);
	}
}
return 0;
}


